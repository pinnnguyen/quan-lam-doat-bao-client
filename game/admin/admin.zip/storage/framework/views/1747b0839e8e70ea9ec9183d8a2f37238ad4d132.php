<?php $__currentLoopData = $html; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $item; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\www\game\game\duo_bao_admin_xpchph\duo_bao_admin\vendor\encore\laravel-admin\src/../resources/views/partials/html.blade.php ENDPATH**/ ?>