<form action="<?php echo $action; ?>" pjax-container style="display: inline-block;">
    <div class="input-group input-group-sm" style="display: inline-block;">
        <input type="text" name="<?php echo e($key, false); ?>" class="form-control grid-quick-search" style="width: 200px;" value="<?php echo e($value, false); ?>" placeholder="<?php echo e($placeholder, false); ?>">

        <div class="input-group-btn" style="display: inline-block;">
            <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
        </div>
    </div>
</form><?php /**PATH /www/wwwroot/duo_bao_admin/vendor/encore/laravel-admin/src/../resources/views/grid/quick-search.blade.php ENDPATH**/ ?>