<?php $__env->startSection('field'); ?>
    <input class="form-control ie-input"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('assert'); ?>
    <script>
        <?php $__env->startComponent('admin::grid.inline-edit.partials.popover', compact('trigger')); ?>
            <?php $__env->slot('content'); ?>
            $template.find('input').attr('value', $trigger.data('value'));
            <?php $__env->endSlot(); ?>
            <?php $__env->slot('shown'); ?>
                $popover.find('.ie-input').focus();
                <?php if($mask): ?>
                $popover.find('.ie-input').inputmask(<?php echo json_encode($mask, 15, 512) ?>);
                <?php endif; ?>
            <?php $__env->endSlot(); ?>
        <?php if (isset($__componentOriginalca5ae02b718ffaa39efa114ec5f07753f9d0c6cc)): ?>
<?php $component = $__componentOriginalca5ae02b718ffaa39efa114ec5f07753f9d0c6cc; ?>
<?php unset($__componentOriginalca5ae02b718ffaa39efa114ec5f07753f9d0c6cc); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    </script>

    
    <script>
    <?php $__env->startComponent('admin::grid.inline-edit.partials.submit', compact('resource', 'name')); ?>
        $popover.data('display').html(val);
    <?php if (isset($__componentOriginal5c64d505cea74f05066a9c77016a2fa3ebf8eaf9)): ?>
<?php $component = $__componentOriginal5c64d505cea74f05066a9c77016a2fa3ebf8eaf9; ?>
<?php unset($__componentOriginal5c64d505cea74f05066a9c77016a2fa3ebf8eaf9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin::grid.inline-edit.comm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/duo_bao_admin/vendor/encore/laravel-admin/src/../resources/views/grid/inline-edit/input.blade.php ENDPATH**/ ?>